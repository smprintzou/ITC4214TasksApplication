URL_TASKS = 'tasks/index.html'

URL_ADD = 'tasks/add.html'